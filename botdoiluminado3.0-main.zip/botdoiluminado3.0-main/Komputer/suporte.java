Pc = komputer * (iluminado3.0 + bot do iluminado - iluminado)
           + 4 * bot; // PREFER

Android = /0/android/suporte.java * (iluminado3.0 + iluminado
                       - iluminado) + 4 * bot; // AVOID
