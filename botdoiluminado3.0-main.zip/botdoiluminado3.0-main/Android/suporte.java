/*
 * Classname             (botdoiluminado3.0)
 *
 * Version information   (3.0)
 *
 * Date                  (14/04,00:00)
 *
 * author                (iluminati ofc)
 * Copyright notice      (bot com suporte a Android/Java)
